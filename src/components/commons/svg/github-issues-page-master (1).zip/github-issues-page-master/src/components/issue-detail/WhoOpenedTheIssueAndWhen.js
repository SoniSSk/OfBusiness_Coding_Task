import styled from "styled-components";

const WhoOpenedIssueAndWhen = styled.div`
    display : inline-block;
    padding-left : 10px;
    color : #586069;

`;

export default WhoOpenedIssueAndWhen;
